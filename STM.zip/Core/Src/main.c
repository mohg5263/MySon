/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * AUTHOR:  Mohammad Ghanatian, PhD Student, Department of Mechanical Engineering, The University of Alabama
 *
 *
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <math.h>


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan1;

TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
// limit data to be within bounds (specific to the AK80-9 motor)
#define P_MIN -12.5f	//position
#define P_MAX 12.5f
#define V_MIN -50.0f	//velocity
#define V_MAX 50.0f
#define T_MIN -18.0f	//torque
#define T_MAX 18.0f
#define Kp_MIN 0.0f
#define Kp_MAX 500.0f
#define Kd_MIN 0.0f
#define Kd_MAX 5.0f

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_CAN1_Init(void);
static void MX_TIM6_Init(void);
/* USER CODE BEGIN PFP */
void CAN1_Tx_motor_on(int);
void CAN1_Tx_motor_zero(int);
void CAN1_Tx_motor_off(int);
void CAN1_Rx_message_read(void);
float interpolateHipAngle(float);
float interpolateKneeAngle(float);
void Stop_Motors(int, int, int, int);

// Prototype of the template function

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
CAN_TxHeaderTypeDef TxHeader;
CAN_RxHeaderTypeDef RxHeader;

uint8_t TxData[8];	//08 bytes of data transmit array, data type dictated by HAL
uint8_t RxData[8];	//08 bytes of data receive array, data type dictated by HAL

uint32_t TxMailbox;	//data type dictated by HAL

int cycle;


int heelSwitchLeft=0;
int heelSwitchRight=0;

int previous_heelSwitchRight = 0;
int previous_heelSwitchLeft = 0;

//Receiving parameter variables
//for motor 1
float position_1 = 0;
float velocity_1 = 0;
float torque_1 = 0;
float temp_1 = 0;
//for motor 2
float position_2 = 0;
float velocity_2 = 0;
float torque_2 = 0;
float temp_2 = 0;
//for motor 3
float position_3 = 0;
float velocity_3 = 0;
float torque_3 = 0;
float temp_3 = 0;
//for motor 4
float position_4 = 0;
float velocity_4 = 0;
float torque_4 = 0;
float temp_4 = 0;

float wPos1 = 0;
float wPos2 = 0;
float wPos3 = 0;
float wPos4 = 0;

float posF1 = 0;
float posF2 = 0;
float posF3 = 0;
float posF4 = 0;


float rAngle1=0;
float rAngle2=0;
float rAngle3=0;
float rAngle4=0;


//********************************************************************************

//switch status
uint8_t buttonStateRight = 0;
uint8_t lastButtonStateRight = 0;

//switch status
uint8_t buttonStateLeft = 0;
uint8_t lastButtonStateLeft = 0;



double hipFactorKp1=1;
double hipFactorKd1=1;

double hipFactorKp2=1;
double hipFactorKd2=1;

double hipFactorKp3=1.5;
double hipFactorKd3=1.5;

double hipFactorKp4=1;
double hipFactorKd4=1;

double hipFactorKp5=4;
double hipFactorKd5=2;


double kneeFactorKp1=1;
double kneeFactorKd1=1;

double kneeFactorKp2=1;
double kneeFactorKd2=1;

double kneeFactorKp3=1.5;
double kneeFactorKd3=1.5;

double kneeFactorKp4=1;
double kneeFactorKd4=1;

double kneeFactorKp5=4;
double kneeFactorKd5=2;

double AngleH1 = 25.0;
double AngleK1 = 10.0;
double AngleH2 = 0.0;
double AngleK2 = 16.0;
double AngleH3 = -20.0;
double AngleK3 = 20.0;
double AngleH4 = 6.0;
double AngleK4 = 40.0;
double AngleH5 = 6.0;
double AngleK5 = 40.0;

// PID variables
int motorID1 = 1;
int motorID2 = 2;
int motorID3 = 3;
int motorID4 = 4;

int motorActivated1 = 1;
int motorActivated2 = 1;
int motorActivated3 = 1;
int motorActivated4 = 1;

double Kp1;
double Kd1;

double Kp2;
double Kd2;

double Kp3;
double Kd3;

double Kp4;
double Kd4;

double samplingTime = 2.5;	//ms

double error1, lastError1 = 0;
double integral1 = 0;
double derivative1;
float torqueF1 = 0;
float speedF1 = 0;
float lastPos1;
float torqSignal1 = 0;

double error2, lastError2 = 0;
double integral2 = 0;
double derivative2;
float torqueF2 = 0;
float speedF2 = 0;
float lastPos2;
float torqSignal2 = 0;

double error3, lastError3 = 0;
double integral3 = 0;
double derivative3;
float torqueF3 = 0;
float speedF3 = 0;
float lastPos3;
float torqSignal3 = 0;

double error4, lastError4 = 0;
double integral4 = 0;
double derivative4;
float torqueF4 = 0;
float speedF4 = 0;
float lastPos4;
float torqSignal4 = 0;

float startTime = 0;
float currentTime = 0;
float ttime = 0;
float ttime1 = 0;
float ttime2 = 0;

//********************************************************************************

float saturate(float x, float x_min, float x_max) {
	if (x < x_min)
		x = x_min;
	else if (x > x_max)
		x = x_max;
	return x;
}

//When sending packets, all numbers need to go through the following function to be converted into integer values before being sent to the motor
int float_to_uint(float x, float x_min, float x_max, unsigned int bits) {
	//Converts a float to an unsigned int, given range and number of intended bits
	float span = x_max - x_min;
	if (x < x_min)
		x = x_min;
	else if (x > x_max)
		x = x_max;
	return (int) ((x - x_min) * ((float) ((1 << bits) / span)));
}

//When receiving, convert all values to floating-point numbers using the following function
float uint_to_float(int x_int, float x_min, float x_max, int bits) {
	// converts unsigned int to float, given range and number of intended bits
	float span = x_max - x_min;
	float offset = x_min;
	return ((float) x_int) * span / ((float) ((1 << bits) - 1)) + offset;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_CAN1_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */
	if (HAL_CAN_Start(&hcan1) != HAL_OK) //CAN is started and checked for error.
			{
		Error_Handler();
	}
	CAN1_Tx_motor_on(motorID1);
	CAN1_Rx_message_read();

	CAN1_Tx_motor_zero(motorID1);
	CAN1_Rx_message_read();

	char msg[50];
	sprintf(msg, "Motor 1 Initialized!\r\n");
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);

	CAN1_Tx_motor_on(motorID2);
	CAN1_Rx_message_read();

	CAN1_Tx_motor_zero(motorID2);
	CAN1_Rx_message_read();

	sprintf(msg, "Motor 2 Initialized!\r\n");
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);

	CAN1_Tx_motor_on(motorID3);
	CAN1_Rx_message_read();

	CAN1_Tx_motor_zero(motorID3);
	CAN1_Rx_message_read();

	sprintf(msg, "Motor 3 Initialized!\r\n");
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);

	CAN1_Tx_motor_on(motorID4);
	CAN1_Rx_message_read();

	CAN1_Tx_motor_zero(motorID4);
	CAN1_Rx_message_read();

	sprintf(msg, "Motor 4 Initialized!\r\n");
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);

	// Start timer
	HAL_TIM_Base_Start_IT(&htim6);

	cycle = 0;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 20;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN1_Init(void)
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 5;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_13TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_2TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = ENABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = ENABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */

	//This is the CAN filter configuration (part of the CAN_INIT code)
	CAN_FilterTypeDef canfilterconfig;

	canfilterconfig.FilterActivation = CAN_FILTER_ENABLE;
	canfilterconfig.FilterBank = 0; // which filter bank to use from the assigned ones
	canfilterconfig.FilterFIFOAssignment = CAN_RX_FIFO0; //this has to be mentioned (FIFO0/ FIFO1)
	canfilterconfig.FilterIdHigh = 0; //Next 04 lines --> no filter mask protocol is going on. All messages are allowed to pass to Nucleo (Accept all frames)
	canfilterconfig.FilterIdLow = 0x0000;
	canfilterconfig.FilterMaskIdHigh = 0;
	canfilterconfig.FilterMaskIdLow = 0x0000;
	canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
	canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
	canfilterconfig.SlaveStartFilterBank = 0; // how many filters to assign to the CAN1 (master can)

	if (HAL_CAN_ConfigFilter(&hcan1, &canfilterconfig) != HAL_OK) {
		Error_Handler();
	}
  /* USER CODE END CAN1_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 4-1;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 50000-1;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 921600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_RTS_CTS;
  huart2.Init.OverSampling = UART_OVERSAMPLING_8;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PC0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin PA6 PA7 */
  GPIO_InitStruct.Pin = LD2_Pin|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PC10 PC11 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void CAN1_Tx_motor_on(int motor_id) {
	TxHeader.DLC = 8;	//data length
	TxHeader.ExtId = 0;
	TxHeader.IDE = CAN_ID_STD;	//standard 11 bit data frame, not extended.
	TxHeader.RTR = CAN_RTR_DATA;
	TxHeader.StdId = motor_id;	//ID of the motor 01
	TxHeader.TransmitGlobalTime = DISABLE;

	TxData[0] = 0xFF;
	TxData[1] = 0xFF;
	TxData[2] = 0xFF;
	TxData[3] = 0xFF;
	TxData[4] = 0xFF;
	TxData[5] = 0xFF;
	TxData[6] = 0xFF;
	TxData[7] = 0xFC;

	while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) == 0) {
		// No available mailbox, wait and retry
		HAL_Delay(1); // Short delay to prevent a tight loop
		char msg[50];
		sprintf(msg, "Transmission needed wait!\r\n");
		HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);
	}

	//message is transmitted through CAN
	if (HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox) != HAL_OK) {
		Error_Handler();
	}

//	// Polling method, Wait for message to get out of pending state, that means wait until the message is transmitted successfully.
//	while (HAL_CAN_IsTxMessagePending(&hcan1, TxMailbox))
//		;

}

void CAN1_Tx_motor_zero(int motor_id) {
	TxHeader.DLC = 8;	//data length
	TxHeader.ExtId = 0;
	TxHeader.IDE = CAN_ID_STD;	//standard 11 bit data frame, not extended.
	TxHeader.RTR = CAN_RTR_DATA;
	TxHeader.StdId = motor_id;	//ID of the motor 01
	TxHeader.TransmitGlobalTime = DISABLE;

	TxData[0] = 0xFF;
	TxData[1] = 0xFF;
	TxData[2] = 0xFF;
	TxData[3] = 0xFF;
	TxData[4] = 0xFF;
	TxData[5] = 0xFF;
	TxData[6] = 0xFF;
	TxData[7] = 0xFE;

	while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) == 0) {
		// No available mailbox, wait and retry
		HAL_Delay(1); // Short delay to prevent a tight loop
		char msg[50];
		sprintf(msg, "Transmission needed wait!\r\n");
		HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);
	}

	//message is transmitted through CAN
	if (HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox) != HAL_OK) {
		Error_Handler();
	}

//	// Polling method, Wait for message to get out of pending state, that means wait until the message is transmitted successfully.
//	while (HAL_CAN_IsTxMessagePending(&hcan1, TxMailbox))
//		;
}

void CAN1_Tx_motor_off(int motor_id) {
	TxHeader.DLC = 8;	//data length
	TxHeader.ExtId = 0;
	TxHeader.IDE = CAN_ID_STD;	//standard 11 bit data frame, not extended.
	TxHeader.RTR = CAN_RTR_DATA;
	TxHeader.StdId = motor_id;	//ID of the motor 01
	TxHeader.TransmitGlobalTime = DISABLE;

	TxData[0] = 0xFF;
	TxData[1] = 0xFF;
	TxData[2] = 0xFF;
	TxData[3] = 0xFF;
	TxData[4] = 0xFF;
	TxData[5] = 0xFF;
	TxData[6] = 0xFF;
	TxData[7] = 0xFD;

	while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) == 0) {
		// No available mailbox, wait and retry
		HAL_Delay(1); // Short delay to prevent a tight loop
		char msg[50];
		sprintf(msg, "Transmission needed wait!\r\n");
		HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);
	}
	//message is transmitted through CAN
	if (HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox) != HAL_OK) {
		Error_Handler();
	}

//	// Polling method, Wait for message to get out of pending state, that means wait until the message is transmitted successfully.
//	while (HAL_CAN_IsTxMessagePending(&hcan1, TxMailbox))
//		;
}

void CAN1_Tx_send_to_motor(int motor_id, float pos, float vel, float kp,
		float kd, float torque) {
//	// For UART
//	char msg[50];

	TxHeader.DLC = 8;	//data length 08 bytes
	TxHeader.ExtId = 0;
	TxHeader.IDE = CAN_ID_STD;	//standard 11 bit data frame, not extended.
	TxHeader.RTR = CAN_RTR_DATA;
	TxHeader.StdId = motor_id;	//ID of the motor 01
	TxHeader.TransmitGlobalTime = DISABLE;

	//ensure that the values of pos, vel, kp, kd, and torque fall within specified bounds
	pos = fminf(fmaxf(P_MIN, pos), P_MAX);
	vel = fminf(fmaxf(V_MIN, vel), V_MAX);
	kp = fminf(fmaxf(Kp_MIN, kp), Kp_MAX);
	kd = fminf(fmaxf(Kd_MIN, kd), Kd_MAX);
	torque = fminf(fmaxf(T_MIN, torque), T_MAX);

	// convert floats to unsigned integers of intended bit size (int uses 4 bytes, 32 bits (same as floats) in this compiler).
	int p_int = float_to_uint(pos, P_MIN, P_MAX, 16);
	int v_int = float_to_uint(vel, V_MIN, V_MAX, 12);
	int kp_int = float_to_uint(kp, Kp_MIN, Kp_MAX, 12);
	int kd_int = float_to_uint(kd, Kd_MIN, Kd_MAX, 12);
	int t_int = float_to_uint(torque, T_MIN, T_MAX, 12);

	// pack integer values into the CAN transfer data array
	//here, the integer values are divided into 08 bit outputs
	TxData[0] = p_int >> 8; // Position High 8
	TxData[1] = p_int & 0xFF; // Position Low 8
	TxData[2] = v_int >> 4; // Speed High 8 bits
	TxData[3] = ((v_int & 0xF) << 4) | (kp_int >> 8); // Speed Low 4 bits, KP High 4 bits
	TxData[4] = kp_int & 0xFF; // KP Low 8 bits
	TxData[5] = kd_int >> 4; // Kd High 8 bits
	TxData[6] = ((kd_int & 0xF) << 4) | (t_int >> 8); // KP Low 4 bits, Torque High 4 bits
	TxData[7] = t_int & 0xff; // Torque Low 8 bits

	while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) == 0) {
		// No available mailbox, wait and retry
		HAL_Delay(1); // Short delay to prevent a tight loop
		char msg[50];
		sprintf(msg, "Transmission needed wait!\r\n");
		HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);
	}
	//message is transmitted through CAN
	if (HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox) != HAL_OK) {
		Error_Handler();
	}

//	// Polling method, Wait for message to get out of pending state, that means wait until the message is transmitted successfully.
//	while (HAL_CAN_IsTxMessagePending(&hcan1, TxMailbox));

}

void CAN1_Rx_message_read(void) {

//	char msg[50];	//for showing over the UART

	//we are waiting for at least one message into the RX FIFO0. When that happens, the following code will get out of the loop.
	//In RX FIFO, you can store 03 CAN messages.
	while (!HAL_CAN_GetRxFifoFillLevel(&hcan1, CAN_RX_FIFO0))
		;

	//Polling based reception of message
	if (HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &RxHeader, RxData) != HAL_OK) //we have to specify the FIFO number
			{
		Error_Handler();
	}

	//Unpacking the received parameter integers from the RxData
	int id = RxData[0]; //motor ID
	int p_int = (RxData[1] << 8) | RxData[2];	//Motor position data
	int v_int = (RxData[3] << 4) | (RxData[4] >> 4);	//Motor velocity data
	int i_int = ((RxData[4] & 0xF) << 8) | RxData[5];	//Motor torque data
	int T_int = RxData[6];	//temperature data
	/// convert int to float
	float p = uint_to_float(p_int, P_MIN, P_MAX, 16);
	float v = uint_to_float(v_int, V_MIN, V_MAX, 12);
	float i = uint_to_float(i_int, T_MIN, T_MAX, 12);
	float T = T_int;
	if (id == motorID1)	//if motor 1 data is received
			{
		position_1 = p; // Read corresponding data based on ID
		velocity_1 = v;
		torque_1 = i;
		temp_1 = T - 40; // Temperature range: -40~215
	}
	if (id == motorID2)	//if motor 1 data is received
			{
		position_2 = p; // Read corresponding data based on ID
		velocity_2 = v;
		torque_2 = i;
		temp_2 = T - 40; // Temperature range: -40~215
	}
	if (id == motorID3)	//if motor 1 data is received
			{
		position_3 = p; // Read corresponding data based on ID
		velocity_3 = v;
		torque_3 = i;
		temp_3 = T - 40; // Temperature range: -40~215
	}
	if (id == motorID4)	//if motor 1 data is received
			{
		position_4 = p; // Read corresponding data based on ID
		velocity_4 = v;
		torque_4 = i;
		temp_4 = T - 40; // Temperature range: -40~215
	}

}


void signalMotors(float rAngle1, float rAngle2, float rAngle3, float rAngle4){

	// Command motor 1 and read current CAN message
	if (motorActivated1) {
		CAN1_Tx_send_to_motor(motorID1, -rAngle1, 0, Kp1, Kd1, 0); //position mode
	} else {
		CAN1_Tx_send_to_motor(motorID1, 0, 0, 0, 0, 0);
	}

	CAN1_Rx_message_read();
	posF1 = -position_1    * 180.0 / M_PI / 65 * 12;
	speedF1 = velocity_1;
	torqueF1 = torque_1;

	// Command motor 1 and read current CAN message
	if (motorActivated2) {
		CAN1_Tx_send_to_motor(motorID2, -rAngle2, 0, Kp2, Kd2, 0); //position mode
	} else {
		CAN1_Tx_send_to_motor(motorID2, 0, 0, 0, 0, 0);
	}

	CAN1_Rx_message_read();
	posF2 = -position_2    * 180.0 / M_PI / 65 * 12;
	speedF2 = velocity_2;
	torqueF2 = torque_2;

	// Command motor 1 and read current CAN message
	if (motorActivated3) {
		CAN1_Tx_send_to_motor(motorID3, rAngle3, 0, Kp3, Kd3, 0); //position mode
	} else {
		CAN1_Tx_send_to_motor(motorID3, 0, 0, 0, 0, 0);
	}

	CAN1_Rx_message_read();
	posF3 = position_3  * 180.0 / M_PI / 65 * 12;
	speedF3 = velocity_3;
	torqueF3 = torque_3;

	// Command motor 1 and read current CAN message
	if (motorActivated4) {
		CAN1_Tx_send_to_motor(motorID4, rAngle4, 0, Kp4, Kd4, 0); //position mode
	} else {
		CAN1_Tx_send_to_motor(motorID4, 0, 0, 0, 0, 0);
	}

	CAN1_Rx_message_read();
	posF4 = position_4 * 180.0 / M_PI / 65 * 12;
	speedF4 = velocity_4;
	torqueF4 = torque_4;






}








void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
	ttime = cycle * samplingTime * 1e-3;
	cycle=cycle+1;


	char msg[100];


	// Scale floating-point variables to integers for efficient processing
	int ttime_int = (int)(ttime * 10000);       // Scale to 4 decimal places
	int posF1_int = (int)(posF1 * 100);         // Scale to 2 decimal places
	int posF2_int = (int)(posF2 * 100);         // Scale to 2 decimal places
	int speedF1_int = (int)(speedF1 * 100);     // Scale to 2 decimal places
	int speedF2_int = (int)(speedF2 * 100);     // Scale to 2 decimal places
	int torqueF1_int = (int)(torqueF1 * 100);   // Scale to 2 decimal places
	int torqueF2_int = (int)(torqueF2 * 100);   // Scale to 2 decimal places
	int posF3_int = (int)(posF3 * 100);         // Scale to 2 decimal places
	int posF4_int = (int)(posF4 * 100);         // Scale to 2 decimal places
	int speedF3_int = (int)(speedF3 * 100);     // Scale to 2 decimal places
	int speedF4_int = (int)(speedF4 * 100);     // Scale to 2 decimal places
	int torqueF3_int = (int)(torqueF3 * 100);   // Scale to 2 decimal places
	int torqueF4_int = (int)(torqueF4 * 100);   // Scale to 2 decimal places



	sprintf(msg, "%d,*%d,%d,%d,%d,%d,%d,%d,*%d,%d,%d,%d,%d,%d,%d\r\n",
	        ttime_int, heelSwitchLeft, posF1_int, posF2_int, speedF1_int, speedF2_int,
	        torqueF1_int, torqueF2_int, heelSwitchRight, posF3_int, posF4_int,
	        speedF3_int, speedF4_int, torqueF3_int, torqueF4_int);

	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);







	static uint8_t lastButtonStateRight = GPIO_PIN_RESET; // Initially not pressed

	uint8_t buttonStateRight = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_10);

	if (buttonStateRight == GPIO_PIN_SET && lastButtonStateRight == GPIO_PIN_RESET) {
		HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);

		char msg[50];
		sprintf(msg, "Heel Switch Right Triggered!" );
		HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);


		if (heelSwitchRight==0 ) {
			heelSwitchRight=1;
		}else if(heelSwitchRight==1){
			heelSwitchRight=heelSwitchRight+1;
		}
	}
	lastButtonStateRight = buttonStateRight;




	static uint8_t lastButtonStateLeft = GPIO_PIN_RESET; // Initially not pressed

	uint8_t buttonStateLeft = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_11);

	if (buttonStateLeft == GPIO_PIN_SET && lastButtonStateLeft == GPIO_PIN_RESET) {
		HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
		char msg[50];
		sprintf(msg, "Heel Switch Left Triggered!" );
		HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);
		if (heelSwitchLeft==0 ) {
			heelSwitchLeft=3;

		}else if (heelSwitchLeft==1) {
			heelSwitchLeft=heelSwitchLeft+1;
		}
	}
	lastButtonStateLeft = buttonStateLeft;




	//1      Waiting Heel Strike
	double KpH1=1*hipFactorKp1;
	double KdH1=0.7*hipFactorKd1;

	double KpK1=1*kneeFactorKp1;
	double KdK1=0.3*kneeFactorKd1;

	//2     Foot flat
	double KpH2=1*hipFactorKp2;
	double KdH2=0.7*hipFactorKd2;

	double KpK2=1*kneeFactorKp2;
	double KdK2=0.7*kneeFactorKd2;




	//3     Hip extension
	double KpH3=3*hipFactorKp3;
	double KdH3=1.5*hipFactorKd3;
	double HipTresh3=-23;

	double KpK3=1*kneeFactorKp3;
	double KdK3=0.7*kneeFactorKd3;



	//4     Knee Flexion Contact Avoider
	double KpH4=0.5*hipFactorKp4;
	double KdH4=0.2*hipFactorKd4;


	double KpK4=0.5*kneeFactorKp4;
	double KdK4=0.2*kneeFactorKd4;
	double KneeTresh4=40;



	//5     Hip Flexion
	double KpH5=0.5*hipFactorKp5;
	double KdH5=0.2*hipFactorKd5;
	double HipTresh5=30;

	double KpK5=0.5*kneeFactorKp5;
	double KdK5=0.1*kneeFactorKd5;

	//	***********************************   Left Leg   ***********************************
	if (heelSwitchLeft==0){

		Kp1=KpH2;
		Kd1=KdH2;

		Kp2=KpK2;
		Kd2=KdK2;

		rAngle1 = AngleH2  / 180.0 * M_PI * 65 / 12;
		rAngle2 = AngleK2  / 180.0 * M_PI * 65 / 12;
	}

	if (heelSwitchLeft==1) {

		Kp1=KpH1;
		Kd1=KdH1;

		Kp2=KpK1;
		Kd2=KdK1;

		rAngle1 = AngleH1  / 180.0 * M_PI * 65 / 12;
		rAngle2 = AngleK1  / 180.0 * M_PI * 65 / 12;
	}

	else if (heelSwitchLeft==2) {

		Kp1=KpH2;
		Kd1=KdH2;

		Kp2=KpK2;
		Kd2=KdK2;

		rAngle1 = AngleH2  / 180.0 * M_PI * 65 / 12;
		rAngle2 = AngleK2  / 180.0 * M_PI * 65 / 12;

		///  Syncing solved
//		if(previous_heelSwitchRight==1 &&  heelSwitchRight==2){
//			heelSwitchLeft=3;
//		}

		if(posF1<0){
			heelSwitchLeft = 3;
		}
	}

	else if (heelSwitchLeft==3) {

		Kp1=KpH3;
		Kd1=KdH3;

		Kp2=KpK3;
		Kd2=KdK3;

		rAngle1 = AngleH3  / 180.0 * M_PI * 65 / 12;
		rAngle2 = AngleK3  / 180.0 * M_PI * 65 / 12;

//		if(posF1<HipTresh3){
//			heelSwitchLeft=4;
//		}

		if(previous_heelSwitchRight==2 &&  heelSwitchRight==3){
			heelSwitchLeft=4;
		}

	}

	else if (heelSwitchLeft==4) {

		Kp1=KpH4;
		Kd1=KdH4;

		Kp2=KpK4;
		Kd2=KdK4;

		rAngle1 = AngleH4  / 180.0 * M_PI * 65 / 12;
		rAngle2 = AngleK4  / 180.0 * M_PI * 65 / 12;


		if(posF2>KneeTresh4){
			heelSwitchLeft=1;

		}
	}

	else if (heelSwitchLeft==5) {

		Kp1=KpH5;
		Kd1=KdH5;

		Kp2=KpK5;
		Kd2=KdK5;

		rAngle1 = AngleH5  / 180.0 * M_PI * 65 / 12;
		rAngle2 = AngleK5  / 180.0 * M_PI * 65 / 12;


		if(posF1>HipTresh5){
			heelSwitchLeft=1;

		}
	}





//	***********************************   Right Leg   ***********************************
	if (heelSwitchRight==0) {

//		Kp3=2;
//		Kd3=0.7;
//
//		Kp4=2;
//		Kd4=0.3;
//
//		rAngle3 = 0 / 180.0 * M_PI * 65 / 12;
//		rAngle4 = 0  / 180.0 * M_PI * 65 / 12;


		Kp3=KpH4;
		Kd3=KdH4;

		Kp4=KpK4;
		Kd4=KdK4;

		rAngle3 = AngleH4  / 180.0 * M_PI * 65 / 12;
		rAngle4 = AngleK4  / 180.0 * M_PI * 65 / 12;
	}


	else if (heelSwitchRight==1) {

		Kp3=KpH1;
		Kd3=KdH1;

		Kp4=KpK1;
		Kd4=KdK1;

		rAngle3 = AngleH1  / 180.0 * M_PI * 65 / 12;
		rAngle4 = AngleK1  / 180.0 * M_PI * 65 / 12;
	}

	else if (heelSwitchRight==2) {

		Kp3=KpH2;
		Kd3=KdH2;

		Kp4=KpK2;
		Kd4=KdK2;

		rAngle3 = AngleH2  / 180.0 * M_PI * 65 / 12;
		rAngle4 = AngleK2  / 180.0 * M_PI * 65 / 12;

		///  syncing solved
//		if(previous_heelSwitchLeft==1 &&  heelSwitchLeft==2){
//			heelSwitchRight=3;
//		}

		if(posF3<0){
			heelSwitchRight = 3;
		}
	}




	else if (heelSwitchRight==3) {

		Kp3=KpH3;
		Kd3=KdH3;

		Kp4=KpK3;
		Kd4=KdK3;

		rAngle3 = AngleH3  / 180.0 * M_PI * 65 / 12;
		rAngle4 = AngleK3  / 180.0 * M_PI * 65 / 12;



//		if(posF3<HipTresh3){
//			heelSwitchRight=4;
//		}

		if(previous_heelSwitchLeft==2 &&  heelSwitchLeft==3){
			heelSwitchRight=4;
		}
	}

	else if (heelSwitchRight==4) {

		Kp3=KpH4;
		Kd3=KdH4;

		Kp4=KpK4;
		Kd4=KdK4;

		rAngle3 = AngleH4  / 180.0 * M_PI * 65 / 12;
		rAngle4 = AngleK4  / 180.0 * M_PI * 65 / 12;

		if(posF4>KneeTresh4){
			heelSwitchRight=1;
		}
	}


	else if (heelSwitchRight==5) {

		Kp3=KpH5;
		Kd3=KdH5;

		Kp4=KpK5;
		Kd4=KdK5;

		rAngle3 = AngleH5  / 180.0 * M_PI * 65 / 12;
		rAngle4 = AngleK5  / 180.0 * M_PI * 65 / 12;

		if(posF3>HipTresh5){
			heelSwitchRight=1;
		}
	}






	signalMotors(rAngle1,rAngle2,rAngle3,rAngle4);

	previous_heelSwitchRight = heelSwitchRight;
	previous_heelSwitchLeft = heelSwitchLeft;





	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);

}

void Stop_Motors(int motor1, int motor2, int motor3, int motor4) {

	if (motor1) {
		motorActivated1 = 0;
	}
	if (motor2) {
		motorActivated2 = 0;
	}
	if (motor3) {
		motorActivated3 = 0;
	}
	if (motor4) {
		motorActivated4 = 0;
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	char msg[50];
	sprintf(msg, "Error Handler Trigerred!\r\n");
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), HAL_MAX_DELAY);
	Stop_Motors(1, 1, 1, 1);

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
